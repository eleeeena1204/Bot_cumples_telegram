#TELEGRAM_TOKEN = "5669613237:AAHZcC0uVk4C0TqFXCrnTz_JIuFxus1zPX0"      #Token botprueba
TELEGRAM_TOKEN = "5631097589:AAFahrCrLCkaFX12oyfbaI7q-mztiE38f2c"       #Token felicidades marinera
GRUPO_ID = -1001306590221   #Grupo prueba
#GRUPO_ID = -1001632214688  #Grupo de mamá
MY_CHAT_ID = 5424769243     #Chat Elena
MY_CHAT_ID_2 = 920099143    #Chat mamá
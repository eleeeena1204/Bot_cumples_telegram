# cumpleBot
#### Bot de Telegram que te recuerda los cumpleaños.

Tiene 4 comandos:
+ start -> Que inicializa el bot
+ nuevo -> Añade un cumpleaños(no se permiten nombres repetidos)
+ borrar -> Elimina un cumpleaños dado el nombre de la persona
+ mostrar -> Muestra todos los cumpleaños guardados
